/* =====================================================================
   Drishti – AI eyes for the visually impaired
   ---------------------------------------------------------------------
   Modes
     GUARD     real-time obstacle detection with SPATIAL AUDIO beeps
               (left/right ear = direction, faster = closer) + vibration
     DESCRIBE  one-shot spoken summary with CLOCK-FACE directions
     READ      OCR of signs / labels / boards, read aloud (Eng/Hin/Kan)
     FIND      "find bottle": Geiger-counter tone guides you to an object
     WASHROOM  / EXIT: our OWN trained model (synthetic data) + OCR fallback
   Everything runs ON THE DEVICE: no images leave the phone.
   ===================================================================== */
'use strict';

// ------------------------------------------------------------------ config
const CFG = {
  detectEveryMs: 160,          // detection loop period
  minScore: 0.5,               // COCO-SSD confidence
  signEveryMs: 650,            // custom sign model period
  signThreshold: 0.85,         // confidence to announce a sign
  signStableFrames: 2,         // consecutive frames before announcing
  announceCooldownMs: 4500,    // don't repeat the same object too often
  vfovDeg: 60,                 // approx. phone camera vertical field of view
  stepMeters: 0.7,
};

// Objects that matter while walking (COCO-SSD class names)
const OBSTACLES = new Set(['person', 'bicycle', 'car', 'motorcycle', 'bus', 'truck', 'chair', 'couch',
  'bench', 'potted plant', 'bed', 'dining table', 'toilet', 'dog', 'cat', 'suitcase', 'fire hydrant',
  'stop sign', 'parking meter', 'refrigerator', 'tv', 'backpack', 'umbrella', 'cow', 'horse', 'sink', 'oven']);

// Typical real-world heights (m) → distance estimate from box height (pinhole model)
const REAL_HEIGHT = { person: 1.65, chair: 0.9, couch: 0.85, bench: 0.8, 'dining table': 0.75, bed: 0.6,
  'potted plant': 0.6, bicycle: 1.0, motorcycle: 1.1, car: 1.5, bus: 3.0, truck: 3.0, dog: 0.5, cat: 0.3,
  suitcase: 0.6, backpack: 0.45, bottle: 0.25, cup: 0.1, 'wine glass': 0.18, 'cell phone': 0.15,
  laptop: 0.25, tv: 0.6, book: 0.24, keyboard: 0.04, mouse: 0.04, remote: 0.18, toilet: 0.75,
  refrigerator: 1.7, sink: 0.3, clock: 0.3, vase: 0.3, umbrella: 0.9, handbag: 0.3, 'teddy bear': 0.3,
  scissors: 0.18, toothbrush: 0.18, banana: 0.2, apple: 0.08, orange: 0.08, bowl: 0.08, 'fire hydrant': 0.8 };

// Spoken word → COCO class (for "find …")
const FIND_ALIASES = {
  bottle: 'bottle', 'water bottle': 'bottle', water: 'bottle', cup: 'cup', mug: 'cup', glass: 'wine glass',
  phone: 'cell phone', mobile: 'cell phone', 'cell phone': 'cell phone', laptop: 'laptop', computer: 'laptop',
  chair: 'chair', seat: 'chair', table: 'dining table', person: 'person', someone: 'person', people: 'person',
  bag: 'backpack', backpack: 'backpack', handbag: 'handbag', purse: 'handbag', book: 'book', remote: 'remote',
  keyboard: 'keyboard', mouse: 'mouse', tv: 'tv', television: 'tv', clock: 'clock', umbrella: 'umbrella',
  scissors: 'scissors', bowl: 'bowl', banana: 'banana', apple: 'apple', toothbrush: 'toothbrush',
  sofa: 'couch', couch: 'couch', bench: 'bench', bed: 'bed', door: null, keys: null, key: null, wallet: null,
};
const FIND_MENU = ['bottle', 'cup', 'phone', 'laptop', 'chair', 'person', 'bag', 'book', 'washroom', 'exit'];
const SIGN_TARGETS = { washroom: ['washroom_men', 'washroom_women'], toilet: ['washroom_men', 'washroom_women'],
  restroom: ['washroom_men', 'washroom_women'], bathroom: ['washroom_men', 'washroom_women'], exit: ['exit_sign'] };
const SIGN_SPEECH = { washroom_men: "Men's washroom sign", washroom_women: "Women's washroom sign", exit_sign: 'Exit sign' };

// ------------------------------------------------------------------ state
const S = {
  mode: 'idle',            // idle | guard | find | sign
  findTarget: null,        // COCO class
  findWord: '',
  signTargets: null,       // e.g. ['exit_sign']
  coco: null, signModel: null, signLabels: [], ocr: null, ocrLang: null,
  lastDetections: [], lastAnnounce: new Map(), signStreak: { label: null, n: 0 },
  lastSignAnnounce: new Map(), busyRead: false, haptics: true, showBoxes: true, verbose: false,
  rate: 1.1, voiceLang: 'en-IN', listening: false, centeredFrames: 0, lastFindSpeak: 0,
  lastSeenTarget: 0, ocrScanBusy: false, lastOcrScan: 0,
};

const $ = (id) => document.getElementById(id);
const video = $('video'), overlay = $('overlay'), ctx = overlay.getContext('2d');
const work = document.createElement('canvas'); // scratch canvas for frames

// ================================================================ SPEECH OUT
let speakingPriority = 0;
function speak(text, { priority = 1, lang } = {}) {
  setCaption(text);
  if (!('speechSynthesis' in window)) return;
  const synth = window.speechSynthesis;
  // Higher priority interrupts; equal/lower priority is dropped while talking (no backlog)
  if (synth.speaking) {
    if (priority > speakingPriority || priority >= 3) synth.cancel();
    else if (priority < 2) return;
  }
  const u = new SpeechSynthesisUtterance(text);
  u.rate = S.rate;
  u.lang = lang || detectScriptLang(text);
  const v = pickVoice(u.lang);
  if (v) u.voice = v;
  speakingPriority = priority;
  u.onend = () => { speakingPriority = 0; };
  synth.speak(u);
}
function detectScriptLang(t) {
  if (/[ಀ-೿]/.test(t)) return 'kn-IN';   // Kannada
  if (/[ऀ-ॿ]/.test(t)) return 'hi-IN';   // Devanagari (Hindi)
  return 'en-IN';
}
let voices = [];
function loadVoices() { voices = window.speechSynthesis ? speechSynthesis.getVoices() : []; }
if ('speechSynthesis' in window) { loadVoices(); speechSynthesis.onvoiceschanged = loadVoices; }
function pickVoice(lang) {
  return voices.find(v => v.lang === lang) || voices.find(v => v.lang.startsWith(lang.slice(0, 2))) || null;
}
function setCaption(t) { $('caption').textContent = t; }

// ================================================================ AUDIO (spatial)
let actx = null;
function audio() {
  if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
  if (actx.state === 'suspended') actx.resume();
  return actx;
}
/** Short beep. pan: -1 (left ear) … +1 (right ear) */
function beep({ freq = 880, dur = 0.07, pan = 0, vol = 0.35, type = 'sine' } = {}) {
  const a = audio(), t = a.currentTime;
  const o = a.createOscillator(), g = a.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  let node = g;
  if (a.createStereoPanner) { const p = a.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, pan)); g.connect(p); node = p; }
  o.connect(g); node.connect(a.destination);
  o.start(t); o.stop(t + dur + 0.02);
}
function chime() { beep({ freq: 660, dur: 0.12 }); setTimeout(() => beep({ freq: 990, dur: 0.18 }), 130); }
function vibrate(p) { if (S.haptics && navigator.vibrate) navigator.vibrate(p); }

// Continuous beeper: a timer whose interval/pan/pitch are updated every frame
const beeper = { timer: null, interval: 0, pan: 0, freq: 880, type: 'sine',
  set(interval, pan, freq, type = 'sine') {
    this.pan = pan; this.freq = freq; this.type = type;
    if (!interval) { this.stop(); return; }
    const changed = Math.abs(interval - this.interval) > 60;
    this.interval = interval;
    if (!this.timer || changed) this.restart();
  },
  restart() {
    clearTimeout(this.timer);
    const tick = () => { beep({ freq: this.freq, pan: this.pan, type: this.type }); this.timer = setTimeout(tick, this.interval); };
    tick();
  },
  stop() { clearTimeout(this.timer); this.timer = null; this.interval = 0; },
};

// ================================================================ GEOMETRY
function frameSize() { return { w: video.videoWidth || 640, h: video.videoHeight || 480 }; }
/** x-centre of box → clock direction (10…2 o'clock across the camera view) */
function clockOf(xFrac) {
  const h = Math.round((xFrac - 0.5) * 4);           // -2 … +2
  const hour = ((12 + h - 1) % 12) + 1;
  return hour === 12 ? "12 o'clock, straight ahead" : `${hour} o'clock`;
}
function sideOf(xFrac) { return xFrac < 0.4 ? 'left' : xFrac > 0.6 ? 'right' : 'ahead'; }
/** Pinhole-camera distance estimate in metres (approximate!) */
function distanceOf(det) {
  const { h } = frameSize();
  const hFrac = Math.max(0.02, det.bbox[3] / h);
  const real = REAL_HEIGHT[det.class] || 0.5;
  // object cut off at top/bottom of frame → it is very close
  const touches = det.bbox[1] < 4 || det.bbox[1] + det.bbox[3] > h - 4;
  let d = real / (2 * Math.tan((CFG.vfovDeg * Math.PI / 180) / 2) * hFrac);
  if (touches && hFrac > 0.7) d = Math.min(d, 0.8);
  return d;
}
function stepsText(m) {
  const steps = Math.max(1, Math.round(m / CFG.stepMeters));
  if (m < 0.8) return 'very close';
  return steps === 1 ? 'about 1 step away' : `about ${steps} steps away`;
}
function xFracOf(det) { return (det.bbox[0] + det.bbox[2] / 2) / frameSize().w; }
function niceName(cls) { return cls === 'cell phone' ? 'phone' : cls === 'dining table' ? 'table' : cls === 'tv' ? 'TV screen' : cls; }
function plural(cls, n) { const w = niceName(cls); return n === 1 ? `a ${w}` : `${n} ${w === 'person' ? 'people' : w + 's'}`; }

// ================================================================ CAMERA + MODELS
async function startCamera() {
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: false,
    video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
  });
  video.srcObject = stream;
  await new Promise(r => (video.readyState >= 2 ? r() : (video.onloadeddata = r)));
  await video.play();
}

async function loadModels() {
  const pill = $('statusModels');
  try {
    await tf.ready();
    S.coco = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
    pill.textContent = `vision: on-device (${tf.getBackend()})`; pill.className = 'pill ok';
  } catch (e) {
    console.error(e); pill.textContent = 'vision model failed'; pill.className = 'pill warn';
    speak('Could not load the vision model. Please check your internet connection for the first load.', { priority: 3 });
  }
  await loadSignModel();
  $('loading').classList.add('hide');
}

/** Our custom Teachable Machine model (trained on synthetic + open data). Optional. */
async function loadSignModel() {
  const pill = $('statusSign');
  try {
    const meta = await (await fetch('model/metadata.json', { cache: 'no-cache' })).json();
    S.signLabels = meta.labels || [];
    S.signModel = await tf.loadLayersModel('model/model.json');
    pill.textContent = `sign model: ${S.signLabels.length} classes`; pill.className = 'pill ok';
  } catch (e) {
    S.signModel = null;
    pill.textContent = 'sign model: not trained yet (OCR fallback)'; pill.className = 'pill warn';
    console.info('Custom sign model not found in app/model/. Using OCR fallback for washroom/exit.', e.message);
  }
}

function grabFrame(maxSide = 1280) {
  const { w, h } = frameSize();
  const s = Math.min(1, maxSide / Math.max(w, h));
  work.width = Math.round(w * s); work.height = Math.round(h * s);
  const c = work.getContext('2d', { willReadFrequently: true });
  c.drawImage(video, 0, 0, work.width, work.height);
  return work;
}

/** Run the custom sign classifier on a centre square crop (Teachable Machine preprocessing). */
function classifySign() {
  if (!S.signModel || !video.videoWidth) return null;
  return tf.tidy(() => {
    const img = tf.browser.fromPixels(video);
    const [h, w] = img.shape;
    const s = Math.min(h, w);
    const crop = img.slice([Math.floor((h - s) / 2), Math.floor((w - s) / 2), 0], [s, s, 3]);
    const input = tf.image.resizeBilinear(crop, [224, 224]).toFloat().div(127.5).sub(1).expandDims(0);
    const probs = S.signModel.predict(input).dataSync();
    let best = 0;
    for (let i = 1; i < probs.length; i++) if (probs[i] > probs[best]) best = i;
    return { label: S.signLabels[best] || `class_${best}`, prob: probs[best] };
  });
}

// ================================================================ DRAWING
function draw(dets, sign) {
  const W = overlay.clientWidth, H = overlay.clientHeight;
  if (overlay.width !== W) overlay.width = W;
  if (overlay.height !== H) overlay.height = H;
  ctx.clearRect(0, 0, W, H);
  if (!S.showBoxes) return;
  // map video pixels → displayed pixels (object-fit: cover)
  const { w: vw, h: vh } = frameSize();
  const scale = Math.max(W / vw, H / vh), ox = (W - vw * scale) / 2, oy = (H - vh * scale) / 2;
  ctx.lineWidth = 4; ctx.font = 'bold 18px system-ui, sans-serif';
  for (const d of dets) {
    const [x, y, w, h] = d.bbox;
    const isTarget = S.mode === 'find' && d.class === S.findTarget;
    const col = isTarget ? '#3ddc84' : OBSTACLES.has(d.class) ? '#ff4d4d' : '#ffd400';
    ctx.strokeStyle = col;
    ctx.strokeRect(ox + x * scale, oy + y * scale, w * scale, h * scale);
    const label = `${niceName(d.class)} · ${distanceOf(d).toFixed(1)}m`;
    const tw = ctx.measureText(label).width + 12;
    ctx.fillStyle = col; ctx.fillRect(ox + x * scale, oy + y * scale - 26, tw, 26);
    ctx.fillStyle = '#000'; ctx.fillText(label, ox + x * scale + 6, oy + y * scale - 7);
  }
  if (S.mode === 'find') { // centre guide
    ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 2; ctx.setLineDash([8, 8]);
    ctx.beginPath(); ctx.moveTo(W * 0.45, 0); ctx.lineTo(W * 0.45, H); ctx.moveTo(W * 0.55, 0); ctx.lineTo(W * 0.55, H); ctx.stroke();
    ctx.setLineDash([]);
  }
  if (sign && sign.label !== 'nothing' && sign.prob > 0.6) {
    const txt = `${SIGN_SPEECH[sign.label] || sign.label} ${(sign.prob * 100).toFixed(0)}%`;
    ctx.font = 'bold 22px system-ui, sans-serif';
    const tw = ctx.measureText(txt).width + 20;
    ctx.fillStyle = '#0046a0'; ctx.fillRect(W - tw - 12, 12, tw, 38);
    ctx.fillStyle = '#fff'; ctx.fillText(txt, W - tw - 2, 39);
  }
}

// ================================================================ MAIN LOOP
let lastSignRun = 0, lastSign = null, loopTimer = null;
async function loop() {
  clearTimeout(loopTimer);
  if (!S.coco || !video.videoWidth) { loopTimer = setTimeout(loop, 300); return; }
  const t0 = performance.now();
  let dets = [];
  try {
    dets = (await S.coco.detect(video, 12, CFG.minScore));
  } catch (e) { console.warn(e); }
  S.lastDetections = dets;

  // custom sign model (lower frequency)
  if (S.signModel && t0 - lastSignRun > CFG.signEveryMs) {
    lastSignRun = t0;
    lastSign = classifySign();
    handleSign(lastSign);
  } else if (!S.signModel && S.mode === 'sign') {
    ocrSignScan(); // fallback: look for washroom / exit words with OCR
  }

  if (S.mode === 'guard') guardStep(dets);
  else if (S.mode === 'find') findStep(dets);
  else if (S.mode === 'sign') beeper.stop();

  draw(dets, lastSign);
  const wait = Math.max(30, CFG.detectEveryMs - (performance.now() - t0));
  loopTimer = setTimeout(loop, wait);
}

// ---------------------------------------------------------------- GUARD
function guardStep(dets) {
  const obstacles = dets.filter(d => OBSTACLES.has(d.class) || S.verbose)
    .map(d => ({ d, x: xFracOf(d), m: distanceOf(d) }));
  if (!obstacles.length) { beeper.stop(); setBadge('GUARD'); return; }

  // Most urgent = closest, weighted towards the walking path (centre)
  const urgency = o => (1 / o.m) * (1.4 - Math.min(1, Math.abs(o.x - 0.5) * 2) * 0.6);
  obstacles.sort((a, b) => urgency(b) - urgency(a));
  const top = obstacles[0];

  // Spatial beep: closer → faster & higher; pan = direction
  if (top.m < 4) {
    const interval = Math.round(Math.max(110, Math.min(1100, top.m * 330)));
    const freq = top.m < 1 ? 1320 : top.m < 2 ? 990 : 740;
    beeper.set(interval, (top.x - 0.5) * 2, freq, top.m < 1 ? 'square' : 'sine');
  } else beeper.stop();

  if (top.m < 1.0 && Math.abs(top.x - 0.5) < 0.3) { vibrate([120, 60, 120]); setBadge('STOP!', true); }
  else setBadge('GUARD');

  // Speak: new or approaching obstacles, rate-limited per class
  for (const o of obstacles.slice(0, 2)) {
    const key = o.d.class, now = Date.now(), prev = S.lastAnnounce.get(key);
    const closer = prev && o.m < prev.m * 0.6;
    if (!prev || now - prev.t > CFG.announceCooldownMs || closer) {
      const urgent = o.m < 1.0;
      speak(`${urgent ? 'Careful! ' : ''}${niceName(o.d.class)}, ${clockOf(o.x)}, ${stepsText(o.m)}.`, { priority: urgent ? 3 : 1 });
      S.lastAnnounce.set(key, { t: now, m: o.m });
      break;
    }
  }
}

// ---------------------------------------------------------------- FIND (Geiger counter)
function findStep(dets) {
  const cands = dets.filter(d => d.class === S.findTarget).sort((a, b) => b.score - a.score);
  const now = Date.now();
  if (!cands.length) {
    S.centeredFrames = 0;
    beeper.set(1300, 0, 330, 'triangle'); // slow, low "searching" tick
    if (now - S.lastFindSpeak > 7000) {
      S.lastFindSpeak = now;
      speak(now - S.lastSeenTarget < 3000 ? `Lost the ${S.findWord}. Move back slowly.` : `Searching for ${S.findWord}. Turn slowly left and right.`);
    }
    setBadge(`FIND: ${S.findWord.toUpperCase()}`);
    return;
  }
  S.lastSeenTarget = now;
  const d = cands[0], x = xFracOf(d), off = Math.abs(x - 0.5), m = distanceOf(d);
  // Closer to centre → faster + higher pitch. Pan tells which way to turn.
  const interval = Math.round(90 + off * 900);
  const freq = 600 + (0.5 - off) * 1200;
  beeper.set(interval, (x - 0.5) * 2, freq, 'sine');
  setBadge(`FOUND ${S.findWord.toUpperCase()}`);
  if (off < 0.1) {
    S.centeredFrames++;
    if (S.centeredFrames === 3 || (S.centeredFrames > 3 && now - S.lastFindSpeak > 5000)) {
      S.lastFindSpeak = now; vibrate([60, 40, 60, 40, 200]); chime();
      speak(`${cap(S.findWord)} straight ahead, ${stepsText(m)}.`, { priority: 2 });
    }
  } else {
    S.centeredFrames = 0;
    if (now - S.lastFindSpeak > 4000) {
      S.lastFindSpeak = now;
      speak(`${cap(S.findWord)} at ${clockOf(x)}. Turn ${x < 0.5 ? 'left' : 'right'}.`);
    }
  }
}
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);

// ---------------------------------------------------------------- SIGNS (custom model)
function handleSign(res) {
  if (!res) return;
  const { label, prob } = res;
  if (label === 'nothing' || prob < CFG.signThreshold) { S.signStreak = { label: null, n: 0 }; return; }
  S.signStreak = S.signStreak.label === label ? { label, n: S.signStreak.n + 1 } : { label, n: 1 };
  if (S.signStreak.n < CFG.signStableFrames) return;
  // In sign-search mode only announce the targets; otherwise announce any sign (passive awareness)
  if (S.mode === 'sign' && S.signTargets && !S.signTargets.includes(label)) return;
  const now = Date.now(), last = S.lastSignAnnounce.get(label) || 0;
  if (now - last < (S.mode === 'sign' ? 4000 : 9000)) return;
  S.lastSignAnnounce.set(label, now);
  chime(); vibrate([80, 50, 80]);
  const conf = Math.round(prob * 100);
  speak(`${SIGN_SPEECH[label] || label} ahead. ${conf} percent sure.${S.mode === 'sign' ? ' Walk towards it, or double tap to read the sign.' : ''}`, { priority: 2 });
}

// OCR fallback for washroom / exit when the custom model is not trained yet
async function ocrSignScan() {
  const now = Date.now();
  if (S.ocrScanBusy || now - S.lastOcrScan < 2500) return;
  S.ocrScanBusy = true; S.lastOcrScan = now;
  try {
    const text = (await runOcr(grabFrame(1000))).text.toUpperCase();
    const hit = matchSignWords(text);
    if (hit && (!S.signTargets || S.signTargets.some(t => hit.labels.includes(t)))) {
      chime(); vibrate([80, 50, 80]);
      speak(`${hit.say}${hit.dir ? ', pointing ' + hit.dir : ''}.`, { priority: 2 });
    }
  } catch (e) { console.warn(e); }
  S.ocrScanBusy = false;
}
function matchSignWords(T) {
  const dir = /\bLEFT\b|←|<-/.test(T) ? 'left' : /\bRIGHT\b|→|->/.test(T) ? 'right' : /\bUP\b|↑|STRAIGHT/.test(T) ? 'straight ahead' : '';
  if (/\b(GENTS|MEN'?S?|MALE|BOYS)\b|पुरुष|ಪುರುಷ/.test(T)) return { say: "Men's washroom sign", labels: ['washroom_men'], dir };
  if (/\b(LADIES|WOMEN'?S?|FEMALE|GIRLS)\b|महिला|ಮಹಿಳೆ/.test(T)) return { say: "Women's washroom sign", labels: ['washroom_women'], dir };
  if (/TOILET|WASHROOM|RESTROOM|LAVATORY|W\.?C\b|शौचालय|ಶೌಚಾಲಯ/.test(T)) return { say: 'Washroom sign', labels: ['washroom_men', 'washroom_women'], dir };
  if (/\bEXIT\b|WAY OUT|निकास|ನಿರ್ಗಮನ/.test(T)) return { say: 'Exit sign', labels: ['exit_sign'], dir };
  return null;
}

// ================================================================ OCR (Read mode)
async function getOcr() {
  const lang = $('setOcrLang').value;
  if (S.ocr && S.ocrLang === lang) return S.ocr;
  if (S.ocr) { await S.ocr.terminate(); S.ocr = null; }
  setCaption('Loading text reader…');
  // window.DRISHTI_OCR_OPTS lets you self-host worker/core/language files (fully offline build)
  S.ocr = await Tesseract.createWorker(lang, 1, window.DRISHTI_OCR_OPTS || {});
  S.ocrLang = lang;
  return S.ocr;
}
/** Grayscale + contrast stretch + upscale small frames → better OCR */
function preprocess(src) {
  const c = document.createElement('canvas');
  const up = src.width < 900 ? 2 : 1;
  c.width = src.width * up; c.height = src.height * up;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.drawImage(src, 0, 0, c.width, c.height);
  const im = g.getImageData(0, 0, c.width, c.height), p = im.data;
  let lo = 255, hi = 0;
  for (let i = 0; i < p.length; i += 4) {
    const y = 0.299 * p[i] + 0.587 * p[i + 1] + 0.114 * p[i + 2];
    p[i] = y; if (y < lo) lo = y; if (y > hi) hi = y;
  }
  const k = 255 / Math.max(1, hi - lo);
  for (let i = 0; i < p.length; i += 4) { const v = (p[i] - lo) * k; p[i] = p[i + 1] = p[i + 2] = v; }
  g.putImageData(im, 0, 0);
  return c;
}
async function runOcr(canvas) {
  const w = await getOcr();
  const { data } = await w.recognize(preprocess(canvas));
  // keep words Tesseract is reasonably sure about
  const words = (data.words || []).filter(x => x.confidence > 55).map(x => x.text);
  const text = words.length ? words.join(' ') : '';
  return { text: text.replace(/\s+/g, ' ').trim(), confidence: data.confidence };
}
async function readText() {
  if (S.busyRead) return;
  S.busyRead = true;
  const prevMode = S.mode;
  beeper.stop(); vibrate(40);
  speak('Reading. Hold steady.', { priority: 2 });
  try {
    const { text } = await runOcr(grabFrame(1600));
    if (!text || text.replace(/[^\p{L}\p{N}]/gu, '').length < 2) {
      speak('I could not find readable text. Move a little closer and hold the phone steady.', { priority: 2 });
    } else {
      const hit = matchSignWords(text.toUpperCase());
      const prefix = hit ? `${hit.say}${hit.dir ? ', pointing ' + hit.dir : ''}. It says: ` : 'It says: ';
      speak(prefix + text, { priority: 2 });
    }
  } catch (e) {
    console.error(e);
    speak('The text reader failed to load. Check the internet connection for the first use.', { priority: 2 });
  }
  S.busyRead = false;
  if (prevMode !== 'idle') setBadge(S.mode.toUpperCase());
}

// ================================================================ DESCRIBE
async function describe() {
  if (!S.coco) { speak('Still loading, one moment.'); return; }
  vibrate(30);
  const dets = await S.coco.detect(video, 20, 0.45);
  const sign = S.signModel ? classifySign() : null;
  const parts = [];
  if (sign && sign.label !== 'nothing' && sign.prob > CFG.signThreshold) parts.push(`${SIGN_SPEECH[sign.label]} in view`);
  if (!dets.length && !parts.length) { speak("I don't recognise any objects. Try turning slowly, or double tap to read text.", { priority: 2 }); return; }
  // group by class, report position of the closest one
  const groups = {};
  for (const d of dets) (groups[d.class] = groups[d.class] || []).push(d);
  const items = Object.entries(groups).map(([cls, arr]) => {
    arr.sort((a, b) => distanceOf(a) - distanceOf(b));
    return { cls, n: arr.length, x: xFracOf(arr[0]), m: distanceOf(arr[0]) };
  }).sort((a, b) => a.m - b.m).slice(0, 5);
  for (const it of items) parts.push(`${plural(it.cls, it.n)} at ${clockOf(it.x)}, ${stepsText(it.m)}`);
  speak(`I see ${parts.join('; ')}.`, { priority: 2 });
}

// ================================================================ MODES
function setBadge(t, alert = false) { const b = $('modeBadge'); b.textContent = t; b.classList.toggle('alert', alert); }
function pressed(id, on) { $(id).setAttribute('aria-pressed', on ? 'true' : 'false'); }
function resetModes() {
  S.mode = 'idle'; S.findTarget = null; S.signTargets = null; beeper.stop();
  ['btnGuard', 'btnFind', 'btnWashroom'].forEach(id => pressed(id, false));
  setBadge('READY');
}
function startGuard() {
  resetModes(); S.mode = 'guard'; pressed('btnGuard', true); setBadge('GUARD');
  S.lastAnnounce.clear();
  speak('Guard mode on. I will beep in the direction of obstacles. Faster beeps mean closer.', { priority: 2 });
}
function stopAll(say = true) { resetModes(); if (say) speak('Stopped.', { priority: 2 }); }
function startFind(word) {
  word = (word || '').toLowerCase().trim().replace(/^(my|the|a|an)\s+/, '');
  if (!word) { openFindDialog(); return; }
  // signs → custom model / OCR
  const signKey = Object.keys(SIGN_TARGETS).find(k => word.includes(k));
  if (signKey) return startSignSearch(signKey);
  const key = Object.keys(FIND_ALIASES).find(k => word === k) || Object.keys(FIND_ALIASES).find(k => word.includes(k));
  const cls = key !== undefined ? FIND_ALIASES[key] : null;
  if (!cls) {
    speak(`Sorry, I can't track ${word} yet. Try bottle, cup, phone, laptop, chair, bag, book or person. You can also say read, to read labels.`, { priority: 2 });
    return;
  }
  resetModes(); S.mode = 'find'; S.findTarget = cls; S.findWord = key === 'water' ? 'bottle' : key;
  S.centeredFrames = 0; S.lastFindSpeak = Date.now(); S.lastSeenTarget = 0;
  pressed('btnFind', true); setBadge(`FIND: ${S.findWord.toUpperCase()}`);
  speak(`Finding ${S.findWord}. Sweep the phone slowly. Faster beeps mean you are pointing at it.`, { priority: 2 });
}
function startSignSearch(key) {
  resetModes(); S.mode = 'sign'; S.signTargets = SIGN_TARGETS[key];
  pressed('btnWashroom', key !== 'exit'); setBadge(key === 'exit' ? 'FIND: EXIT' : 'FIND: WASHROOM');
  speak(`Looking for ${key === 'exit' ? 'an exit' : 'a washroom'} sign. Turn slowly and point the phone at walls and doors at head height.`, { priority: 2 });
}
function help() {
  speak('Say guard to detect obstacles. Describe, to hear what is around you. Read, to read text. Find, followed by an object, like find bottle. Find washroom, or find exit, for signs. Say stop to stop. You can also tap the screen to describe, double tap to read, or press and hold to talk.', { priority: 2 });
}

// ================================================================ VOICE COMMANDS
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null;
function listen() {
  if (!SR) { speak('Voice commands are not supported in this browser. Please use Chrome.', { priority: 2 }); return; }
  if (S.listening) { rec && rec.stop(); return; }
  window.speechSynthesis && speechSynthesis.cancel();
  beeper.stop();
  rec = new SR();
  rec.lang = S.voiceLang; rec.interimResults = false; rec.maxAlternatives = 3;
  rec.onstart = () => { S.listening = true; $('btnMic').classList.add('listening'); beep({ freq: 1040, dur: 0.08 }); setCaption('Listening…'); };
  rec.onend = () => { S.listening = false; $('btnMic').classList.remove('listening'); };
  rec.onerror = (e) => { if (e.error !== 'no-speech' && e.error !== 'aborted') speak(`Voice error: ${e.error}.`); };
  rec.onresult = (e) => {
    const alts = Array.from(e.results[0]).map(a => a.transcript.toLowerCase().trim());
    handleCommand(alts[0], alts);
  };
  try { rec.start(); } catch (e) { console.warn(e); }
}
function handleCommand(text, alts = [text]) {
  setCaption(`“${text}”`);
  const t = text;
  const m = t.match(/(?:find|where(?:'s| is)|locate|search(?: for)?|look for)\s+(.+)/);
  if (m) return startFind(m[1]);
  if (/\b(washroom|toilet|restroom|bathroom|loo)\b/.test(t)) return startSignSearch('washroom');
  if (/\bexit\b|way out/.test(t)) return startSignSearch('exit');
  if (/\b(stop|pause|quiet|cancel)\b/.test(t)) return stopAll();
  if (/\b(guard|walk|navigate|obstacle|start)\b/.test(t)) return startGuard();
  if (/\b(read|text|sign|label)\b/.test(t)) return readText();
  if (/\b(describe|what|around|see|look|scene)\b/.test(t)) return describe();
  if (/\b(help|commands)\b/.test(t)) return help();
  // try alternatives before giving up
  for (const a of alts.slice(1)) if (a !== text && /find|read|guard|stop|describe|washroom|exit|help/.test(a)) return handleCommand(a, [a]);
  speak(`Sorry, I didn't understand “${text}”. Say help for commands.`, { priority: 2 });
}

// ================================================================ GESTURES & UI
function setupGestures() {
  const st = $('stage');
  let pressTimer = null, lastTap = 0, tapTimer = null, longFired = false;
  st.addEventListener('pointerdown', () => {
    longFired = false;
    pressTimer = setTimeout(() => { longFired = true; vibrate(50); listen(); }, 600);
  });
  const cancel = () => clearTimeout(pressTimer);
  st.addEventListener('pointerleave', cancel);
  st.addEventListener('pointercancel', cancel);
  st.addEventListener('pointerup', () => {
    cancel();
    if (longFired) return;
    const now = Date.now();
    if (now - lastTap < 320) { clearTimeout(tapTimer); lastTap = 0; readText(); }
    else { lastTap = now; tapTimer = setTimeout(describe, 330); }
  });
  st.addEventListener('contextmenu', e => e.preventDefault());
}
function openFindDialog() {
  const grid = $('findGrid'); grid.innerHTML = '';
  for (const w of FIND_MENU) {
    const b = document.createElement('button'); b.textContent = cap(w);
    b.onclick = () => { $('findDialog').close(); startFind(w); };
    grid.appendChild(b);
  }
  $('findDialog').showModal();
  speak('What should I find? Or press and hold the screen and say, find bottle.');
}
function setupUI() {
  $('btnGuard').onclick = () => (S.mode === 'guard' ? stopAll() : startGuard());
  $('btnDescribe').onclick = describe;
  $('btnRead').onclick = readText;
  $('btnFind').onclick = () => (S.mode === 'find' ? stopAll() : openFindDialog());
  $('btnWashroom').onclick = () => (S.mode === 'sign' ? stopAll() : startSignSearch('washroom'));
  $('btnMic').onclick = listen;
  $('btnStop').onclick = () => stopAll();
  $('findCancel').onclick = () => $('findDialog').close();
  $('btnSettings').onclick = () => {
    const s = $('settings'); s.hidden = !s.hidden; $('btnSettings').setAttribute('aria-expanded', String(!s.hidden));
  };
  // settings (persisted per device; storage may be unavailable → ignore)
  const bind = (id, key, prop = 'value', apply = v => v) => {
    const el = $(id);
    try { const v = localStorage.getItem('drishti.' + key); if (v !== null) el[prop] = prop === 'checked' ? v === 'true' : v; } catch (_) {}
    const upd = () => { S[key] = apply(el[prop]); try { localStorage.setItem('drishti.' + key, String(el[prop])); } catch (_) {} };
    el.addEventListener('change', upd); el.addEventListener('input', upd); upd();
  };
  bind('setRate', 'rate', 'value', Number);
  bind('setOcrLang', 'ocrLangPref');
  bind('setVoiceLang', 'voiceLang');
  bind('setHaptics', 'haptics', 'checked');
  bind('setBoxes', 'showBoxes', 'checked');
  bind('setVerbose', 'verbose', 'checked');

  document.addEventListener('keydown', e => {
    if (e.target.matches('input, select, textarea') || e.metaKey || e.ctrlKey || $('findDialog').open) return;
    const k = e.key.toUpperCase();
    const map = { G: () => (S.mode === 'guard' ? stopAll() : startGuard()), D: describe, R: readText,
      F: () => openFindDialog(), W: () => startSignSearch('washroom'), E: () => startSignSearch('exit'),
      V: listen, S: () => stopAll(), H: help, ' ': describe };
    if (map[k]) { e.preventDefault(); map[k](); }
  });
}

// ================================================================ BOOT
async function boot() {
  $('startScreen').hidden = true;
  $('app').hidden = false;
  audio(); // unlock audio on user gesture
  speak('Welcome to Drishti. Starting the camera.', { priority: 3 });
  try {
    await startCamera();
  } catch (e) {
    console.error(e);
    speak('I could not open the camera. Please allow camera access. The app must be opened over https or on localhost.', { priority: 3 });
    return;
  }
  setupGestures();
  await loadModels();
  loop();
  speak('Ready. Tap the screen to hear what is around you, or press and hold to give a voice command. Say help for all commands.', { priority: 2 });
}

setupUI();
$('startScreen').addEventListener('click', boot, { once: true });
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  navigator.serviceWorker.register('sw.js').catch(e => console.info('SW not registered', e));
}

// expose for quick debugging in the console / tests
window.drishti = { S, handleCommand, clockOf, stepsText, matchSignWords, startFind, startGuard, stopAll };
